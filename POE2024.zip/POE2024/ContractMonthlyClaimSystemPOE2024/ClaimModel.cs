using System.ComponentModel.DataAnnotations;

namespace LecturerClaimsApp.Models
{
    public class ClaimModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Lecturer Name is required")]
        public string LecturerName { get; set; }

        [Range(1, 1000, ErrorMessage = "Hours worked must be between 1 and 1000")]
        public double HoursWorked { get; set; }

        [Range(1, 1000, ErrorMessage = "Hourly rate must be between 1 and 1000")]
        public double HourlyRate { get; set; }

        // New properties for file upload
        public string FileName { get; set; }
        public string FilePath { get; set; }

        public string Notes { get; set; }
        // New property to track the status of the claim
        public string Status { get; set; } = "Pending"; // Default status is Pending

        // This is a calculated field for the total claim amount
        public double TotalClaim => HoursWorked * HourlyRate;
    }
}
