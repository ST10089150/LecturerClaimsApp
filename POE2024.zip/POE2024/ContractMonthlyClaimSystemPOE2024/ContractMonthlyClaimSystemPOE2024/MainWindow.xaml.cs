﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Collections.ObjectModel;
using System.Windows;

namespace ContractMonthlyClaimSystem
{
    public partial class MainWindow : Window
    {
        // Sample data model for claims
        public class Claim
        {
            public int ClaimID { get; set; }
            public string DateSubmitted { get; set; }
            public string Status { get; set; }
        }

        // ObservableCollection to bind to the DataGrid
        public ObservableCollection<Claim> Claims { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            // Initialize the claims collection
            Claims = new ObservableCollection<Claim>
            {
                new Claim { ClaimID = 12345, DateSubmitted = "2024-08-15", Status = "Pending" },
                new Claim { ClaimID = 12346, DateSubmitted = "2024-07-14", Status = "Approved" }
            };

            // Bind the Claims collection to the DataGrid
            ClaimsDataGrid.ItemsSource = Claims;
        }

        // Event handler for Submit Claim button
        private void SubmitClaimBtn_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Redirecting to the Submit New Claim form.");
        }

        // Event handler for Upload Supporting Documents button
        private void UploadDocsBtn_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.DefaultExt = ".pdf"; // Default file extension
            dlg.Filter = "PDF Documents (*.pdf)|*.pdf|All Files (*.*)|*.*"; // File types

            bool? result = dlg.ShowDialog();

            if (result == true)
            {
                string filename = dlg.FileName;
                MessageBox.Show("File uploaded: " + filename);
            }
        }

        // Event handler for View Claims button
        private void ViewClaimsBtn_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Showing all submitted claims.");
        }
    }
}

